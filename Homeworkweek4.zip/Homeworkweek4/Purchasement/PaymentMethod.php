<?php
interface PaymentMethod{
    public function paymentMethod();
}

?>